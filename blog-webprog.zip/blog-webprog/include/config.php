<?php

define("DSN", "mysql:host=localhost;dbname=blog_webprog;charset=utf8");
define("DB_USER" , "root");
define("DB_PASS" , "");


