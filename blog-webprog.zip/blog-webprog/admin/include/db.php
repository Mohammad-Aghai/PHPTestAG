<?php

$db = new PDO(DSN, DB_USER, DB_PASS);