<nav class="col-md-2 d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="index.php">
                    <i class="fas fa-home"></i>
                    داشبورد
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="post.php">
                    <i class="fas fa-file-image"></i>
                    مقالات
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="category.php">
                    <i class="fas fa-folder-open"></i>
                    دسته بندی
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="comment.php">
                    <i class="fas fa-comments"></i>
                    کامنت
                </a>
            </li>

        </ul>

    </div>
</nav>